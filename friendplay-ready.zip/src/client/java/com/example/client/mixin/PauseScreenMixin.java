package com.example.client.mixin;

import com.example.client.InviteManager;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.PauseScreen;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.server.IntegratedServer;
import net.minecraft.network.chat.Component;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

// Mojang mappings (mặc định của template Fabric cho 1.21.11)
@Mixin(PauseScreen.class)
public abstract class PauseScreenMixin extends Screen {

    protected PauseScreenMixin(Component title) {
        super(title);
    }

    @Inject(method = "init", at = @At("TAIL"))
    private void friendplay$addInviteButton(CallbackInfo ci) {
        Minecraft mc = Minecraft.getInstance();
        IntegratedServer server = mc.getSingleplayerServer();
        if (server == null) return; // chỉ hiện khi đang chơi world đơn

        Button invite = Button.builder(Component.literal("Mời bạn"),
                btn -> InviteManager.invite(mc, server))
                .bounds(8, 8, 90, 20)
                .build();

        this.addRenderableWidget(invite);
    }
}
