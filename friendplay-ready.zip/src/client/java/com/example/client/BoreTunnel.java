package com.example.client;

import java.io.BufferedInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.Socket;
import java.nio.charset.StandardCharsets;
import java.util.function.BooleanSupplier;
import java.util.function.Consumer;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Tunnel TCP qua server công khai bore.pub (không cần tài khoản, không cần mở port).
 * Giao thức: JSON kết thúc bằng byte 0 trên cổng điều khiển 7835.
 */
public final class BoreTunnel {
    private static final String SERVER = "bore.pub";
    private static final int CONTROL_PORT = 7835;

    private static final Pattern HELLO = Pattern.compile("\\{\"Hello\":(\\d+)}");
    private static final Pattern CONNECTION = Pattern.compile("\\{\"Connection\":\"([0-9a-fA-F-]+)\"}");
    private static final Pattern ERROR = Pattern.compile("\\{\"Error\":\"(.*)\"}");

    private volatile boolean active = true;
    private volatile Socket control;

    private BoreTunnel() {}

    /** Chạy tunnel ở thread nền. onReady nhận cổng công khai trên bore.pub. */
    public static BoreTunnel start(int localPort, BooleanSupplier keepRunning,
                                   Consumer<Integer> onReady, Consumer<String> onError) {
        BoreTunnel tunnel = new BoreTunnel();
        Thread thread = new Thread(() -> tunnel.run(localPort, keepRunning, onReady, onError), "friendplay-tunnel");
        thread.setDaemon(true);
        thread.start();
        return tunnel;
    }

    public boolean isActive() {
        return active;
    }

    public void close() {
        active = false;
        closeQuietly(control);
    }

    private void run(int localPort, BooleanSupplier keepRunning,
                     Consumer<Integer> onReady, Consumer<String> onError) {
        try {
            Socket socket = new Socket(SERVER, CONTROL_PORT);
            control = socket;
            socket.setSoTimeout(10_000); // server gửi heartbeat ~0.5s/lần

            InputStream in = new BufferedInputStream(socket.getInputStream());
            send(socket.getOutputStream(), "{\"Hello\":0}"); // 0 = server tự chọn cổng

            String reply = readMessage(in);
            if (reply == null) throw new IOException("bore.pub đóng kết nối");
            Matcher hello = HELLO.matcher(reply);
            if (!hello.matches()) throw new IOException("Phản hồi lạ từ bore.pub: " + reply);
            onReady.accept(Integer.parseInt(hello.group(1)));

            while (active && keepRunning.getAsBoolean()) {
                String msg = readMessage(in);
                if (msg == null) throw new IOException("Mất kết nối tới bore.pub");

                Matcher conn = CONNECTION.matcher(msg);
                if (conn.matches()) {
                    String id = conn.group(1);
                    Thread t = new Thread(() -> forward(id, localPort), "friendplay-conn");
                    t.setDaemon(true);
                    t.start();
                    continue;
                }
                Matcher err = ERROR.matcher(msg);
                if (err.matches()) throw new IOException(err.group(1));
                // "Heartbeat" và các tin khác: bỏ qua
            }
        } catch (IOException e) {
            if (active) onError.accept(e.getMessage());
        } finally {
            active = false;
            closeQuietly(control);
        }
    }

    /** Mỗi người chơi vào = 1 kết nối mới: nối bore.pub <-> world local. */
    private static void forward(String id, int localPort) {
        Socket remote = null;
        Socket local = null;
        try {
            remote = new Socket(SERVER, CONTROL_PORT);
            local = new Socket("127.0.0.1", localPort);
            send(remote.getOutputStream(), "{\"Accept\":\"" + id + "\"}");

            final Socket r = remote;
            final Socket l = local;
            Thread up = new Thread(() -> pipe(l, r), "friendplay-pipe");
            up.setDaemon(true);
            up.start();
            pipe(r, l);
        } catch (IOException e) {
            closeQuietly(remote);
            closeQuietly(local);
        }
    }

    private static void pipe(Socket from, Socket to) {
        try {
            InputStream in = from.getInputStream();
            OutputStream out = to.getOutputStream();
            byte[] buf = new byte[8192];
            int n;
            while ((n = in.read(buf)) != -1) {
                out.write(buf, 0, n);
                out.flush();
            }
        } catch (IOException ignored) {
            // một phía đóng là bình thường
        } finally {
            closeQuietly(from);
            closeQuietly(to);
        }
    }

    private static void send(OutputStream out, String json) throws IOException {
        out.write(json.getBytes(StandardCharsets.UTF_8));
        out.write(0);
        out.flush();
    }

    private static String readMessage(InputStream in) throws IOException {
        ByteArrayOutputStream buf = new ByteArrayOutputStream();
        int b;
        while ((b = in.read()) != -1) {
            if (b == 0) return buf.toString(StandardCharsets.UTF_8);
            buf.write(b);
        }
        return null;
    }

    private static void closeQuietly(Socket s) {
        if (s == null) return;
        try {
            s.close();
        } catch (IOException ignored) {
        }
    }
}
