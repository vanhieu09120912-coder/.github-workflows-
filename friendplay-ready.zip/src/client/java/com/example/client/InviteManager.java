package com.example.client;

import net.minecraft.client.Minecraft;
import net.minecraft.client.server.IntegratedServer;
import net.minecraft.network.chat.Component;

public final class InviteManager {
    private static final int PORT = 25565;

    private static BoreTunnel tunnel;
    private static String address;

    private InviteManager() {}

    public static void invite(Minecraft mc, IntegratedServer server) {
        // Đã có tunnel đang chạy: chỉ copy lại địa chỉ
        if (tunnel != null && tunnel.isActive() && address != null) {
            copyAndTell(mc);
            return;
        }

        // 1) Mở world ra LAN (nếu chưa mở)
        if (!server.isPublished()
                && !server.publishServer(server.getDefaultGameType(), false, PORT)) {
            say(mc, "Không mở được world trên cổng " + PORT + " (có thể đang bận)");
            return;
        }

        // 2) Bật tunnel ra internet
        say(mc, "Đang tạo đường hầm...");
        int localPort = server.getPort();
        address = null;
        tunnel = BoreTunnel.start(
                localPort,
                server::isRunning,
                remotePort -> mc.execute(() -> {
                    address = "bore.pub:" + remotePort;
                    copyAndTell(mc);
                }),
                error -> mc.execute(() -> say(mc, "Lỗi tunnel: " + error)));
    }

    private static void copyAndTell(Minecraft mc) {
        mc.keyboardHandler.setClipboard(address);
        say(mc, "Đã copy địa chỉ: " + address
                + " | Gửi cho bạn bè: Multiplayer > Add Server > dán địa chỉ.");
    }

    private static void say(Minecraft mc, String msg) {
        if (mc.player != null) {
            mc.player.displayClientMessage(Component.literal(msg), false);
        }
    }
}
